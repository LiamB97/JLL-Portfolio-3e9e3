import {Composition} from "remotion";
import {FullFilm} from "./FullFilm";
export const RemotionRoot=()=> <Composition id="JLL-Full-Film" component={FullFilm} width={1920} height={1080} fps={24} durationInFrames={4320}/>;
