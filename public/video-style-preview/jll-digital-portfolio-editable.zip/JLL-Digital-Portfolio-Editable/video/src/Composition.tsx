import {AbsoluteFill, Img, Interactive, staticFile, useCurrentFrame, useVideoConfig, interpolate, Easing} from 'remotion';
import {Audio} from '@remotion/media';
import {loadFont} from '@remotion/fonts';
import {TransitionSeries, linearTiming} from '@remotion/transitions';
import {slide} from '@remotion/transitions/slide';
import anchors from '../public/map-assets/map-metadata.json';

const MIDNIGHT='#131E29', SPACE='#003E51', SAND='#E0C6AD';
const clamp={extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
const ease=Easing.bezier(.19,1,.22,1);
const smooth=Easing.bezier(.65,0,.25,1);
const font='JLLSans, sans-serif';
await Promise.all([
  loadFont({family:'JLLSans',url:staticFile('brand/source-light.ttf'),weight:'300'}),
  loadFont({family:'JLLSans',url:staticFile('brand/source-regular.ttf'),weight:'400'}),
  loadFont({family:'JLLSans',url:staticFile('brand/source-semibold.ttf'),weight:'600'}),
  loadFont({family:'JLLSerif',url:staticFile('brand/serif-italic.ttf'),weight:'300',style:'italic'}),
]);

const Reveal=({text,delay=0,size=160,color='white'}:{text:string;delay?:number;size?:number;color?:string})=>{
 const f=useCurrentFrame();
 return <div style={{height:size*1.12,overflow:'hidden'}}><div style={{fontFamily:font,fontSize:size,fontWeight:300,letterSpacing:-size*.035,lineHeight:1.05,color,translate:`0 ${interpolate(f,[delay,delay+23],[size*1.15,0],{...clamp,easing:ease})}px`}}>{text}</div></div>;
};

const OpeningInner=()=>{
 const f=useCurrentFrame();
 return <AbsoluteFill style={{backgroundColor:MIDNIGHT,overflow:'hidden'}}>
   <Img src={staticFile('brand/london.jpg')} style={{width:'100%',height:'100%',objectFit:'cover',objectPosition:'52% 50%',scale:interpolate(f,[0,96],[1.12,1.015],{...clamp,easing:smooth})}}/>
   <AbsoluteFill style={{background:'linear-gradient(90deg,rgba(19,30,41,.78) 0%,rgba(19,30,41,.35) 52%,rgba(19,30,41,.10) 100%)'}}/>
   <AbsoluteFill style={{background:'linear-gradient(0deg,#131e29b0,transparent 50%)'}}/>
   <div style={{position:'absolute',left:96,top:325}}><Reveal text="London" delay={8} size={190}/><Reveal text="New Homes." delay={15} size={190}/></div>
   <div style={{position:'absolute',left:102,top:790,height:64,overflow:'hidden'}}><div style={{fontFamily:'JLLSerif',fontSize:45,fontWeight:300,fontStyle:'italic',color:SAND,translate:`0 ${interpolate(f,[31,55],[64,0],{...clamp,easing:ease})}px`}}>A new perspective on London.</div></div>
 </AbsoluteFill>;
};
export const Opening=Interactive.create({Component:OpeningInner,layout:'absolute-fill'});

const Pointer=({x,y,press}:{x:number;y:number;press:boolean})=><div style={{position:'absolute',left:x,top:y,width:46,height:58,scale:press?.85:1,filter:'drop-shadow(0 4px 5px #0004)',pointerEvents:'none'}}><svg viewBox="0 0 32 40" width="46" height="58"><path d="M3 2L4 32l8-8 7 13 6-3-7-13 11-1Z" fill="white" stroke={MIDNIGHT} strokeWidth="2" strokeLinejoin="round"/></svg></div>;

const MapPin=({x,y,index,name,selected,age,shown}:{x:number;y:number;index:number;name:string;selected:boolean;age:number;shown:boolean})=>{
 const pulse=selected?interpolate(age,[0,22,45],[.7,1.7,1.9],clamp):1;
 return <div style={{position:'absolute',left:x,top:y,opacity:shown?1:0,scale:shown?1:0,translate:'-50% -100%'}}>
  {selected?<div style={{position:'absolute',left:38,top:39,width:112,height:112,border:`3px solid ${SAND}`,background:'#e0c6ad33',borderRadius:100,translate:'-50% -50%',scale:pulse,opacity:interpolate(age,[0,30,50],[.9,.2,0],clamp)}}/>:null}
  <svg width="78" height="93" viewBox="0 0 78 93" style={{display:'block',filter:'drop-shadow(0 5px 7px #003e5144)',scale:interpolate(age,[0,8,18],[.8,1.11,1],clamp)}}>
   <path d="M39 4C20 4 6 18 6 36c0 22 33 51 33 51s33-29 33-51C72 18 58 4 39 4Z" fill={selected?SAND:SPACE} stroke="white" strokeWidth="4"/>
   {selected?<path d="m25 35 10 10 20-23" fill="none" stroke={SPACE} strokeWidth="5" strokeLinecap="round" strokeLinejoin="round"/>:<circle cx="39" cy="35" r="8" fill="white"/>}
  </svg>
  <div style={{position:'absolute',left:index===1?-15:91,top:index===1?98:5,translate:index===1?'-75% 0':'0 0',whiteSpace:'nowrap',padding:'12px 20px',border:'1px solid #d6d1cb',borderRadius:10,boxShadow:'0 7px 22px #003e5116',fontFamily:font,fontSize:28,fontWeight:600,color:SPACE,background:'white'}}>{name}</div>
 </div>;
};

const WorkbenchInner=()=>{
 const f=useCurrentFrame();
 const pane=interpolate(f,[80,106],[0,1],{...clamp,easing:ease});
 const share=interpolate(f,[174,197],[0,1],{...clamp,easing:ease});
 const mapZoom=interpolate(f,[0,72,106,180,242],[1.2,1.13,.98,.98,.92],{...clamp,easing:smooth});
 const mapX=interpolate(f,[0,72,106,180,242],[-250,-200,400,400,480],{...clamp,easing:smooth});
 const mapY=interpolate(f,[0,72,106,180,242],[-305,-260,-170,-170,-125],{...clamp,easing:smooth});
 const count=f<98?0:f<134?1:f<168?2:3;
 const state=count;
 const pointerOpacity=interpolate(f,[83,90,174,187,230,242],[0,1,1,1,1,0],clamp);
 const px=f<170?interpolate(f,[85,96,117,132,151,166],[180,140,140,140,140,140],{...clamp,easing:smooth}):interpolate(f,[172,197,223],[140,495,495],{...clamp,easing:smooth});
 const py=f<170?interpolate(f,[85,96,117,132,151,166],[560,520,520,655,655,790],{...clamp,easing:smooth}):interpolate(f,[172,197,223],[790,635,635],{...clamp,easing:smooth});
 const press=[98,134,168,216].some(at=>Math.abs(f-at)<=3);
 return <AbsoluteFill style={{backgroundColor:'#f2f2f0',overflow:'hidden'}}>
  <Img src={staticFile('map-assets/london-map-2x.png')} style={{position:'absolute',left:0,top:0,width:2400,height:1500,transformOrigin:'0 0',translate:`${mapX}px ${mapY}px`,scale:mapZoom,opacity:interpolate(f,[75,106],[.82,1],clamp)}}/>
  <div style={{position:'absolute',left:0,top:0,bottom:0,width:1080,translate:`${(1-pane)*-1080}px 0`,backgroundColor:MIDNIGHT,borderRight:`3px solid ${SAND}`,boxShadow:'25px 0 80px #131e2912'}}/>
  <div style={{position:'absolute',left:96,top:250,width:710,opacity:1-pane,translate:`0 ${-pane*45}px`}}>
    <Reveal text="A clearer way" delay={10} size={105} color={SPACE}/><Reveal text="to explore." delay={17} size={105} color={SPACE}/>
    <div style={{marginTop:62,display:'flex',alignItems:'center',gap:22,padding:'20px 24px',background:'white',color:SPACE,fontFamily:font,fontWeight:400,fontSize:35,borderRadius:9,width:674,opacity:interpolate(f,[32,53],[0,1],{...clamp,easing:ease}),translate:`0 ${interpolate(f,[32,53],[25,0],{...clamp,easing:ease})}px`}}><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke={SPACE} strokeWidth="1.8"><circle cx="10" cy="10" r="7"/><path d="m15 15 6 6"/></svg><span>Explore an area or postcode</span></div>
  </div>
  <div style={{position:'absolute',left:96,top:216,width:936,opacity:pane*(1-share),translate:`${(1-pane)*-50}px ${-share*35}px`}}>
   <div style={{fontFamily:font,fontSize:87,fontWeight:300,lineHeight:1.07,letterSpacing:-2.5,color:'white'}}>Handpick the right<br/>developments.</div>
   <div style={{position:'absolute',left:0,top:236,width:936,height:408,overflow:'hidden',background:'white',borderRadius:8,boxShadow:'0 20px 45px #0003'}}>
    <Img src={staticFile(`ui-assets/collection-selection-${state}.png`)} style={{width:2070.43,height:408.096,display:'block'}}/>
   </div>
   <div style={{position:'absolute',left:0,top:666,fontFamily:'JLLSerif',fontWeight:300,fontStyle:'italic',fontSize:36,color:SAND}}>{count} of 3 homes selected</div>
  </div>
  <div style={{position:'absolute',left:96,top:225,width:785,opacity:share,translate:`0 ${(1-share)*45}px`}}>
   <div style={{fontFamily:font,fontSize:91,fontWeight:300,lineHeight:1.08,letterSpacing:-2.5,color:'white'}}>Share a personal<br/>collection.</div>
   <div style={{marginTop:48,background:'white',padding:'20px 24px',color:SPACE,fontFamily:font,fontSize:31,borderRadius:8,border:'1px solid #d6d1cb'}}>Your personal collection link</div>
   <div style={{marginTop:28,width:742,overflow:'hidden',borderRadius:8}}><Img src={staticFile('ui-assets/collection-share-actions-compact.png')} style={{width:780,display:'block'}}/></div>
   <div style={{marginTop:34,fontFamily:'JLLSerif',fontStyle:'italic',fontWeight:300,fontSize:36,color:SAND,opacity:interpolate(f,[218,235],[0,1],{...clamp,easing:ease})}}>One link. Your handpicked homes.</div>
  </div>
  {anchors.developmentAnchors.map((p,i)=>{
    const order=i===0?0:i===1?1:2;const at=[98,134,168][order];const names=['100 George Street','SEVEN, Southbank Place','Mandarin Oriental, Mayfair'];
    return <MapPin key={p.id} x={p.x*mapZoom+mapX} y={p.y*mapZoom+mapY} index={i} name={names[i]} shown={f>17+i*8} selected={f>=at} age={Math.max(0,f-at)} />;
  })}
  <div style={{position:'absolute',right:30,bottom:151,fontFamily:font,fontSize:17,color:SPACE,background:'#ffffffdb',padding:'4px 8px'}}>© OpenStreetMap contributors</div>
  <div style={{position:'absolute',left:0,top:0,opacity:pointerOpacity}}><Pointer x={px} y={py} press={press}/></div>
 </AbsoluteFill>;
};
export const Workbench=Interactive.create({Component:WorkbenchInner,layout:'absolute-fill'});

const ClosingInner=()=>{
 const f=useCurrentFrame();
 return <AbsoluteFill style={{backgroundColor:MIDNIGHT,overflow:'hidden'}}>
   <Img src={staticFile('brand/jll-dark.svg')} style={{position:'absolute',left:96,top:56,width:355,zIndex:100}}/>
   <div style={{position:'absolute',left:96,top:240,width:1180}}><Reveal text="Your buyer." delay={5} size={152}/><Reveal text="Your relationship." delay={14} size={152}/></div>
   <div style={{position:'absolute',left:101,top:635,fontFamily:'JLLSerif',fontSize:47,fontWeight:300,fontStyle:'italic',color:SAND,opacity:interpolate(f,[26,47],[0,1],{...clamp,easing:ease}),translate:`0 ${interpolate(f,[26,47],[25,0],{...clamp,easing:ease})}px`}}>London New Homes. Personally selected.</div>
   <div style={{position:'absolute',left:103,top:768,display:'flex',alignItems:'center',gap:20,opacity:interpolate(f,[30,55],[0,1],{...clamp,easing:ease}),translate:`0 ${interpolate(f,[30,55],[20,0],{...clamp,easing:ease})}px`}}><Img src={staticFile('brand/whatsapp.svg')} style={{width:55,height:55}}/><span style={{fontFamily:font,fontSize:42,fontWeight:400,color:'white'}}>Your JLL broker</span></div>
 </AbsoluteFill>;
};
export const Closing=Interactive.create({Component:ClosingInner,layout:'absolute-fill'});

const Brand=()=>{const f=useCurrentFrame();const light=interpolate(f,[84,96,164,190],[0,1,1,0],clamp);return <div style={{position:'absolute',left:96,top:56,width:355,zIndex:100,opacity:f<354?1:0}}><Img src={staticFile('brand/jll-dark.svg')} style={{width:'100%',display:'block',opacity:1-light}}/><Img src={staticFile('brand/jll-light.svg')} style={{position:'absolute',left:0,top:0,width:'100%',display:'block',opacity:light}}/></div>;};
const Captions=()=>{
 const f=useCurrentFrame();const {fps}=useVideoConfig();const t=f/fps;
 const lines=[{s:3,e:5.30,text:'A clearer way to explore.'},{s:6,e:8.35,text:'Handpick the right developments.'},{s:8.85,e:11.15,text:'Share a personal collection.'},{s:11.7,e:14.5,text:'Keep every buyer conversation with you.'}];
 const line=lines.find(l=>t>=l.s&&t<l.e);
 return line?<div style={{position:'absolute',bottom:0,left:0,right:0,height:124,display:'flex',alignItems:'center',justifyContent:'center',paddingBottom:12,backgroundColor:MIDNIGHT,fontFamily:font,fontSize:43,fontWeight:400,color:'white'}}>{line.text}</div>:null;
};

export const StyleDraft=()=> <AbsoluteFill style={{backgroundColor:MIDNIGHT,fontFamily:font}}>
 <TransitionSeries>
  <TransitionSeries.Sequence name="London opening" durationInFrames={96}><Opening name="London opening scene" /></TransitionSeries.Sequence>
  <TransitionSeries.Transition timing={linearTiming({durationInFrames:12})} presentation={slide({direction:'from-bottom'})}/>
  <TransitionSeries.Sequence name="Explore, select and share" durationInFrames={282}><Workbench name="Map and collection workflow" /></TransitionSeries.Sequence>
  <TransitionSeries.Transition timing={linearTiming({durationInFrames:12})} presentation={slide({direction:'from-right'})}/>
  <TransitionSeries.Sequence name="Buyer relationship" durationInFrames={96}><Closing name="Personal broker closing" /></TransitionSeries.Sequence>
 </TransitionSeries>
 <Brand />
 <Captions />
 <Audio src={staticFile('audio/soundtrack.wav')} />
</AbsoluteFill>;
